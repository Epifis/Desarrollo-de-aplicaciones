package co.edu.unipiloto.stationadviser;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class EmailActivity extends AppCompatActivity {

    private EditText toAddress;
    private EditText subject;
    private EditText message;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_email);

        // Inicializar vistas
        toAddress = findViewById(R.id.to_address);
        subject = findViewById(R.id.subject);
        message = findViewById(R.id.message);

        // Configurar título de la acción bar
        setTitle("Enviar Correo");
    }

    public void sendEmail(View view) {
        String to = toAddress.getText().toString().trim();
        String subj = subject.getText().toString().trim();
        String msg = message.getText().toString().trim();

        // Validar campos
        if (to.isEmpty() || subj.isEmpty() || msg.isEmpty()) {
            Toast.makeText(this, R.string.email_empty, Toast.LENGTH_SHORT).show();
            return;
        }

        // Crear un mensaje detallado para mostrar en Toast
        String previewMessage = " CORREO ENVIADO\n\n" +
                "PARA: " + to + "\n\n" +
                "ASUNTO: " + subj + "\n\n" +
                "MENSAJE:\n" + msg + "\n\n" +
                "FECHA: " + getCurrentDateTime();

        // Toast más largo para que se pueda leer
        Toast.makeText(this, previewMessage, Toast.LENGTH_LONG).show();

        // Limpiar campos después de enviar
        clearFields();
    }

    private void clearFields() {
        toAddress.setText("");
        subject.setText("");
        message.setText("");
    }

    private String getCurrentDateTime() {
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        return sdf.format(new java.util.Date());
    }

    // Método opcional para limpiar campos manualmente
    public void clearFields(View view) {
        clearFields();
        Toast.makeText(this, "Campos limpiados", Toast.LENGTH_SHORT).show();
    }
}