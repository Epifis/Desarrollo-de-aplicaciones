package co.edu.unipiloto.stationadviser;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.text.NumberFormat;

public class FuelActivity extends AppCompatActivity {

    private EditText employeeName;
    private Spinner fuelType;
    private EditText gallons;
    private EditText pricePerGallon;
    private TextView totalAmount;
    private EditText pumpNumber;
    private EditText vehiclePlate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fuel);

        // Inicializar vistas
        employeeName = findViewById(R.id.employee_name);
        fuelType = findViewById(R.id.fuel_type);
        gallons = findViewById(R.id.gallons);
        pricePerGallon = findViewById(R.id.price_per_gallon);
        totalAmount = findViewById(R.id.total_amount);
        pumpNumber = findViewById(R.id.pump_number);
        vehiclePlate = findViewById(R.id.vehicle_plate);

        // Configurar spinner de tipos de combustible
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.fuel_types, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        fuelType.setAdapter(adapter);

        // Configurar título
        setTitle("Registro de Combustible");

        // Agregar listeners para calcular automáticamente el total
        setupTotalCalculator();
    }

    private void setupTotalCalculator() {
        TextWatcher calculator = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                calculateTotal();
            }
        };

        gallons.addTextChangedListener(calculator);
        pricePerGallon.addTextChangedListener(calculator);
    }

    private void calculateTotal() {
        try {
            String gallonsStr = gallons.getText().toString();
            String priceStr = pricePerGallon.getText().toString();

            if (!gallonsStr.isEmpty() && !priceStr.isEmpty()) {
                double gallonsValue = Double.parseDouble(gallonsStr);
                double priceValue = Double.parseDouble(priceStr);
                double total = gallonsValue * priceValue;

                // Formatear como moneda
                NumberFormat currencyFormat = NumberFormat.getCurrencyInstance();
                totalAmount.setText(currencyFormat.format(total));
            } else {
                totalAmount.setText("$ 0.00");
            }
        } catch (NumberFormatException e) {
            totalAmount.setText("$ 0.00");
        }
    }

    public void saveRecord(View view) {
        // Validar campos
        if (employeeName.getText().toString().trim().isEmpty() ||
                gallons.getText().toString().trim().isEmpty() ||
                pricePerGallon.getText().toString().trim().isEmpty() ||
                pumpNumber.getText().toString().trim().isEmpty() ||
                vehiclePlate.getText().toString().trim().isEmpty()) {

            Toast.makeText(this, R.string.invalid_data, Toast.LENGTH_SHORT).show();
            return;
        }

        // Obtener valores
        String employee = employeeName.getText().toString().trim();
        String fuelTypeSelected = fuelType.getSelectedItem().toString();
        String gallonsValue = gallons.getText().toString().trim();
        String priceValue = pricePerGallon.getText().toString().trim();
        String total = totalAmount.getText().toString();
        String pump = pumpNumber.getText().toString().trim();
        String vehicle = vehiclePlate.getText().toString().trim();

        // Crear mensaje detallado para Toast
        String recordMessage = "REGISTRO GUARDADO\n\n" +
                "Empleado: " + employee + "\n" +
                "Tipo: " + fuelTypeSelected + "\n" +
                "Galones: " + gallonsValue + "\n" +
                "Precio/Galón: $" + priceValue + "\n" +
                "Total: " + total + "\n" +
                "Bomba #: " + pump + "\n" +
                "Vehículo: " + vehicle + "\n\n" +
                "Fecha: " + getCurrentDateTime();

        Toast.makeText(this, recordMessage, Toast.LENGTH_LONG).show();

        // Limpiar campos después de guardar
        clearFields();
    }

    private void clearFields() {
        employeeName.setText("");
        fuelType.setSelection(0);
        gallons.setText("");
        pricePerGallon.setText("");
        pumpNumber.setText("");
        vehiclePlate.setText("");
        totalAmount.setText("$ 0.00");
    }

    public void clearFields(View view) {
        clearFields();
        Toast.makeText(this, "Campos limpiados", Toast.LENGTH_SHORT).show();
    }

    private String getCurrentDateTime() {
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        return sdf.format(new java.util.Date());
    }
}