package co.edu.unipiloto.stationadviser;

import java.util.ArrayList;
import java.util.List;

public class StationExpert {

    public List<String> getStations(String zone) {
        List<String> stations = new ArrayList<>();

        if (zone.equals("Norte")) {
            stations.add("Estación Norte - Carrera 45 #80-20");
            stations.add("Estación Industrial - Calle 72 #45-30");
            stations.add("Estación Universidad - Av. 68 #55-10");
        } else if (zone.equals("Sur")) {
            stations.add("Estación Sur - Carrera 30 #20-15");
            stations.add("Estación Terminal - Calle 10 #15-50");
            stations.add("Estación Hospital - Av. Caracas #8-65");
        } else if (zone.equals("Oriente")) {
            stations.add("Estación Oriental - Carrera 7 #45-20");
            stations.add("Estación Centro - Calle 19 #5-40");
            stations.add("Estación Parque - Carrera 5 #35-12");
        } else if (zone.equals("Occidente")) {
            stations.add("Estación Occidental - Av. 68 #100-30");
            stations.add("Estación Comercial - Calle 100 #50-25");
            stations.add("Estación Industrial - Carrera 68 #75-18");
        } else {
            stations.add("No hay estaciones disponibles para la zona seleccionada");
        }

        return stations;
    }
}