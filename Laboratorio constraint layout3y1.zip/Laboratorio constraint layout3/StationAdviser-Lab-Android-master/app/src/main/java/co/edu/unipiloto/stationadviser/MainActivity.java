package co.edu.unipiloto.stationadviser;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Configurar título
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Station Adviser");
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_email) {
            Intent intent = new Intent(this, EmailActivity.class);
            startActivity(intent);
            Toast.makeText(this, "Abriendo formulario de correo", Toast.LENGTH_SHORT).show();
            return true;

        } else if (id == R.id.action_fuel) {
            Intent intent = new Intent(this, FuelActivity.class);
            startActivity(intent);
            Toast.makeText(this, "Abriendo registro de combustible", Toast.LENGTH_SHORT).show();
            return true;

        } else if (id == R.id.action_stations) {
            Toast.makeText(this, "Buscador de estaciones", Toast.LENGTH_SHORT).show();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void onClickFindStation(View view) {
        try {
            Spinner spinner = findViewById(R.id.zones);

            if (spinner == null) {
                Toast.makeText(this, "Error: Spinner no encontrado", Toast.LENGTH_SHORT).show();
                return;
            }

            String zone = spinner.getSelectedItem() != null ?
                    spinner.getSelectedItem().toString() : "";

            if (zone.isEmpty()) {
                Toast.makeText(this, "Por favor seleccione una zona", Toast.LENGTH_SHORT).show();
                return;
            }

            TextView stationsView = findViewById(R.id.stations);

            if (stationsView == null) {
                Toast.makeText(this, "Error: TextView no encontrado", Toast.LENGTH_SHORT).show();
                return;
            }

            StationExpert expert = new StationExpert();
            List<String> stationList = expert.getStations(zone);

            StringBuilder formattedStations = new StringBuilder();

            if (stationList != null && !stationList.isEmpty()) {
                for (String station : stationList) {
                    formattedStations.append("• ").append(station).append("\n\n");
                }
            } else {
                formattedStations.append("No hay estaciones disponibles para la zona seleccionada");
            }

            stationsView.setText(formattedStations.toString());

            Toast.makeText(this, "Mostrando estaciones de la zona " + zone,
                    Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}